"use client"

import { DashboardHome } from "@/components/dashboard-home"

export default function DashboardPage() {
  return <DashboardHome locale="mn" />
}
