# VexoAI — Railway + Neon Deploy Guide

## 1. GitHub-д push хийх

```bash
git init
git remote add origin https://github.com/Zulzaga0428/VexiAI.git
git add .
git commit -m "feat: Railway deploy ready"
git push -u origin main
```

## 2. Neon Database тохируулах

Хэрэв Supabase ашиглаж байгаа бол энэ хэсгийг алгасаж болно.
Neon ашиглах бол [neon.tech](https://neon.tech) дээр project үүсгэж `DATABASE_URL` авна.

## 3. Railway-д deploy хийх

1. [railway.app](https://railway.app) → **New Project** → **Deploy from GitHub repo**
2. `VexiAI` repo-г сонгоно
3. **Variables** tab дээр дараах env vars-уудыг нэмнэ:

```
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=
FAL_KEY=
ANTHROPIC_API_KEY=
CAMB_API_KEY=
BLOB_READ_WRITE_TOKEN=
QPAY_USERNAME=
QPAY_PASSWORD=
QPAY_INVOICE_CODE=
NEXT_PUBLIC_APP_URL=https://your-app.railway.app
ADMIN_EMAILS=
```

4. **Deploy** дарна → Railway автоматаар Dockerfile ашиглан build хийнэ

## 4. Custom domain (vexoai.studio)

Railway → Settings → Domains → **Add Custom Domain** → `vexoai.studio`
DNS-д Railway-н өгсөн CNAME record-г нэмнэ.

## 5. Supabase Auth callback URL шинэчлэх

Supabase dashboard → Authentication → URL Configuration:
- **Site URL**: `https://vexoai.studio`
- **Redirect URLs**: `https://vexoai.studio/auth/callback`

## Орон нутгийн dev

```bash
cp .env.example .env.local
# .env.local дотор бүх key-үүдийг бөглөнө
pnpm install
pnpm dev
```
